Start: `npm run dev`
post/put ky time url parameters nahi bhejny 
get by specific id k lye,get, delete k lye bhej skty
edit or create krty waqt hi sirf check krna hoga createdby wali condition
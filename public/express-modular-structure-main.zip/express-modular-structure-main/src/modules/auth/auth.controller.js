// src/modules/auth/auth.controller.js
const authService = require("./auth.service");

const register = async (req, res) => {
  const { username, email, password } = req.body;
  const result = await authService.registerUser({ username, email, password });

  return res.status(201).json({
    success: true,
    message: "User registered successfully",
    data: { user: result.user, token: result.token },
  });
};

const login = async (req, res) => {
  const { login, password } = req.body;
  const result = await authService.loginUser({ login, password });

  return res.json({
    success: true,
    message: "Login successful",
    data: { user: result.user, token: result.token },
  });
};

const getMe = async (req, res) => {
  const result = await authService.getUserById(req.user._id);
  return res.json({ success: true, data: { user: result.user } });
};

module.exports = { register, login, getMe };

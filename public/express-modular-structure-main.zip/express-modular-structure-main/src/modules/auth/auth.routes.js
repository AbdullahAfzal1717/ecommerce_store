// src/modules/auth/auth.routes.js
const express = require("express");
const { register, login, getMe } = require("./auth.controller");
const protect = require("../../middlewares/auth.middleware");
const validate = require("../../middlewares/validate.middleware");
const { registerValidator, loginValidator } = require("./auth.validator");
const asyncHandler = require("../../utils/asyncHandler");
const { populate } = require("../../models/category.model");

const router = express.Router();

router.post("/register", registerValidator, validate, asyncHandler(register));
router.post("/login", loginValidator, validate, asyncHandler(login));
router.get("/me", protect, getMe);

module.exports = router;
populate
const router = require('./auth.routes');
module.exports = router;

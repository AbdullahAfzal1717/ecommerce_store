
const router = require("./subcategory.routes");
module.exports = router;

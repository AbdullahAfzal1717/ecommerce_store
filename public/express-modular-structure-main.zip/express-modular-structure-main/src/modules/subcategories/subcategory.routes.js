const express = require("express");
const {
  getSubCategories,
  getSubCategory,
  createSubCategory,
  updateSubCategory,
  deleteSubCategory,
} = require("./subcategory.controller");
const protect = require("../../middlewares/auth.middleware");
const { subCategoryValidator, updateSubCategoryValidator } = require("./subcategory.validator");
const validate = require("../../middlewares/validate.middleware");
const asyncHandler = require("../../utils/asyncHandler");

const router = express.Router();

router.get("/", asyncHandler(getSubCategories));
router.get("/:id", asyncHandler(getSubCategory));
router.post("/", subCategoryValidator, validate, protect, asyncHandler(createSubCategory));
router.put("/", updateSubCategoryValidator, validate, protect, asyncHandler(updateSubCategory));
router.delete("/:id", protect, asyncHandler(deleteSubCategory));

module.exports = router;
 
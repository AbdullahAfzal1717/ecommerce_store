const { param } = require("../auth");
const subcategoryService = require("./subcategory.service");


const getSubCategories = async (req, res) => {
  const result = await subcategoryService.getAllSubCategories();

  return res.status(200).json({
    success: true,
    message: "Categories fetched successfully",
    count: result.length,
    data: result,
  });
};


const getSubCategory = async (req, res) => {
  const result = await subcategoryService.getSubCategoryById(req.params.id);

  return res.status(200).json({
    success: true,
    message: "Category fetched successfully",
    data: result,
  });
};


const createSubCategory = async (req, res) => {
  const { title, description, catId } = req.body;
  const result = await subcategoryService.createSubCategory({ title, description, catId, createdBy: req.user._id });

  return res.status(201).json({
    success: true,
    message: "Subcategory created successfully",
    data: { subCategory: result.subCategory },
  });
};

const updateSubCategory = async (req, res) => {
  const { title, description , catId, subCategoryId } = req.body;
  const result = await subcategoryService.updateSubCategory({
    title, description, userId: req.user._id,catId, subCategoryId   
  });

  return res.status(200).json({
    success: true,
    message: "Subcategory updated successfully",
    data: result,
  });
};



const deleteSubCategory = async (req, res) => {
  const result = await subcategoryService.deleteSubCategory({
    id: req.params.id,
    userId: req.user._id,
  });

  return res.status(200).json({
    success: true,
    message: "SubCategory deleted successfully",
    data: result,
  });
};


module.exports = {
  getSubCategories,
  getSubCategory,
  createSubCategory,
  updateSubCategory,
  deleteSubCategory,
};

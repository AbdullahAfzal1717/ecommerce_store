
const router = require("./product.routes");
module.exports = router;


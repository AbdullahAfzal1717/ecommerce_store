const express = require("express");
const {
  getProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
} = require("./product.controller");
const protect = require("../../middlewares/auth.middleware");
const { addProductValidator, updateSubCategoryValidator } = require("./product.validator");
const validate = require("../../middlewares/validate.middleware");
const asyncHandler = require("../../utils/asyncHandler");

const router = express.Router();

router.get("/", asyncHandler(getProducts));
router.get("/:id", asyncHandler(getProduct));
router.post("/", addProductValidator, validate, protect, asyncHandler(createProduct));
// router.put("/", updateSubCategoryValidator, validate, protect, asyncHandler(updateProduct));
router.delete("/:id", protect, asyncHandler(deleteProduct));

module.exports = router;
 
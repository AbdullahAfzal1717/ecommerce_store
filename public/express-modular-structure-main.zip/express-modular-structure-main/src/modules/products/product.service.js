const { validationResult } = require("express-validator");
const SubCategory = require("../../models/subCategory.model");
const Category = require("../../models/category.model");
const ApiError = require("../../utils/ApiError");
const { default: mongoose } = require("mongoose");
const Product = require("../../models/product.model");

async function getAllProducts() {
  const products = await Product.find()
    .populate({
      path: "subCategory",
      select: "title description",
      populate: {
        path: "category",
        select: "title description",
      },
    })
    .populate("createdBy", "username email")
    .sort({ createdAt: -1 });

  return products;
}


async function getProductById(id) {
  const product = await Product.findById(id)
    .populate("createdBy","username email")
    .populate("category", "title description");
  if (!product) throw new ApiError("SubCategory not found", 404);
  return product;
}


async function createProduct({  title, description, subCategory, quantity, price, createdBy }) {
  // basic input validation (controller/validator should normally handle this)
  if (!title || !description || !subCategory || !quantity || !price) {
    throw new ApiError("Product, title, description, subCategory, quantity, price are required", 400);
  }
  const checkSubCategory = await SubCategory.findById(subCategory);
  if (!checkSubCategory) {
    throw new ApiError("SubCategory doest not exist", 400);
  }
  
  // create new user
  const product = await Product.create({ title, description, subCategory, quantity, price, createdBy })
  await product.populate("createdBy", "username email");
  await product.populate({
      path: "subCategory",
      select: "title description",
      populate: {
        path: "category",
        select: "title description",
      },
    })
  return {
    product
  };
}


async function updateProduct({ title, description, userId, catId, subCategoryId }) {
  const subCategory = await SubCategory.findById(subCategoryId);
  if (!subCategory) throw new ApiError("SubCategory not found", 404);

  const catIdCheck = await Category.findById(catId);
  if (!catIdCheck) {
    throw new ApiError("Category doest not exist", 400);
  }

  if (subCategory.createdBy.toString() !== userId.toString()) {
    throw new ApiError("Not authorized to update this Subcategory", 403);
  }

  subCategory.title = title || subCategory.title;
  subCategory.description = description || subCategory.description;

  const updatedSubCategory = await subCategory.save();
  await updatedSubCategory.populate("createdBy", "username email");
  await updatedSubCategory.populate("category", "title description");


  return updatedSubCategory;
}


// async function deleteSubCategory({ id, userId }) {
//   const category = await Category.findById(id);
//   if (!category) throw new ApiError("Category not found", 404);

//   if (category.createdBy.toString() !== userId.toString()) {
//     throw new ApiError("Not authorized to delete this category", 403);
//   }

//   await category.deleteOne();
//   return true;
// }


async function deleteProduct({ id, userId }) {
  const subCategory = await SubCategory.findById(id);
  if (!subCategory) throw new ApiError("SubCategory not found", 404);

  if (subCategory.createdBy.toString() !== userId.toString()) {
    throw new ApiError("Not authorized to delete this SubCategory", 403);
  }

  await SubCategory.findByIdAndDelete(id);

  return { _id: id };
}

module.exports = {
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
};

const express = require("express");
const {
  getCategories,
  getCategory,
  createCategory,
  updateCategory,
  deleteCategory,
} = require("./category.controller");
const protect = require("../../middlewares/auth.middleware");
const { categoryValidator } = require("./category.validator");
const validate = require("../../middlewares/validate.middleware");
const asyncHandler = require("../../utils/asyncHandler");

const router = express.Router();

router.get("/", asyncHandler(getCategories));
router.get("/:id", asyncHandler(getCategory));
router.post("/", categoryValidator, validate, protect, asyncHandler(createCategory));
router.put("/", categoryValidator, validate, protect, asyncHandler(updateCategory));
router.delete("/:id", protect, asyncHandler(deleteCategory));

module.exports = router;
 
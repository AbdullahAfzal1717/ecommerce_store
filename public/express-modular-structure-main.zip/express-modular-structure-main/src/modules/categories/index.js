const router = require('./category.routes');
module.exports = router;
